## v0.4.0

Added Signal Monitor (thanks @justcallmekoko!) to support new sigmon command in Marauder v0.10.5: https://github.com/justcallmekoko/ESP32Marauder/releases

Added keyboard and +5V support from unleashed (thanks @xMasterX!)
