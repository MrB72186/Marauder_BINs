#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define WIFI_MARAUDER_APP_VERSION "v0.6.0"

typedef struct WifiMarauderApp WifiMarauderApp;

#ifdef __cplusplus
}
#endif
